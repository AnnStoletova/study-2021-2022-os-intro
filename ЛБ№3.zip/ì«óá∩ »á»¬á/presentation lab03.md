## Front matter
lang: ru-RU
название: Структурный подход к методу глубокого обучения
автор: столетова Анна Алексеевна

институт: 

дата: NEC--2019, 30 сентября -- 4 октября, 2019 Будва, Черногория

## Форматирование
toc: false
slide_level: 2
тема: 
заголовок metropolis-включает: 
 - \metroset{progressbar=frametitle,sectionpage=progressbar,numbering=fraction}
 - '\makeatletter'
 - '\beamer@ignorenonframefalse'
 - '\ makeatother'spectratio
: 43
раздел-названия: true
---
# Markdown
## Цель работы 
  - Научиться оформлять отчёты с помощью легковесного языка разметки Markdown.
## Задание
  1. Сделать отчёт по предыдущей лабораторной работе в формате Markdown.
  2. В качестве отчёта предоставить отчёты в 3 форматах: pdf, docx и md (в архиве,
поскольку он должен содержать скриншоты, Makefile и т.д.)

## Теоретическое введение
Markdown — облегчённый язык разметки, созданный с целью обозначения форматирования в простом тексте, с максимальным сохранением его читаемости человеком, и пригодный для машинного преобразования в языки для продвинутых публикаций (HTML, Rich Text и других).

## Выполнение лабораторной работы
1.Создали файл <i>report.md</i> и создали в нем шаблон отчета (рис.1).
![Шаблон отчета](https://avatars.mds.yandex.net/get-images-cbir/1597963/7_dij7P11bBJH2n_SNgX5Q3919/ocr)

##

2.Создали папку <i>images</i> для хранения картинок и перенесли туда скриншоты из второй лабораторной работы. (рис.2).
![Скриншоты второй лабораторной работы](https://avatars.mds.yandex.net/get-images-cbir/485180/XmaFzRUmHgNFzvxUF7Y0ZQ3899/ocr)

##

3.Открыли отчет второй лабораторной работы в формате docx (рис.3).
![Отчет второй лабораторной работы в docx](https://avatars.mds.yandex.net/get-images-cbir/2380475/yupPdnvKkMNyDbZ60jI5og3856/ocr)

##

4.Перенесли отчет из docx в отчет в формате markdown (рис.4).
![Перенесенный отчет их docx в md](https://avatars.mds.yandex.net/get-images-cbir/1056619/IsWWIHnOJ-9LZMKUCCy13A4350/ocr)

##

5.Конвертируем md файл в pdf  и docx используя pandoc (рис.5).
![Перенесенный отчет из docx в md](https://avatars.mds.yandex.net/get-images-cbir/1038743/dbTim69QFkGhHqpmFQuIPA3792/ocr)

## Вывод

Научились использовать разметку Markdown для написания отчетов, а также использование pandoc для конвертации md в pdf и docx.








